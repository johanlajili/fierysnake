(function() {
    alert("IMPORTANT NOTICE:\n\nThe demo you're viewing uses Ludei's default configuration.\n\nFacebook, Ads, Analytics, Multiplayer, Notification, Social and Store services require configuration on Ludei's cloud system.\nPlease, refer to Custom Launcher help for more info.");
})();