(function() {

    /**********************************
     * Fetch products from server
     *******************************/

    var a = null;
    CocoonJS.Store.onProductsFetchStarted.addEventListener(function() {
        console.log("onProductsFetchStarted");
    });

    CocoonJS.Store.onProductsFetchFailed.addEventListener(function() {
        console.log("onProductsFetchFailed");
    });

    CocoonJS.Store.onProductsFetchCompleted.addEventListener(function(products) {
        for (var i = products.length - 1; i >= 0; i--) {
            CocoonJS.Store.addProduct(products[i]);
            console.log("Adding product to the local database: " + JSON.stringify(products[i]));
        };

        console.log("onProductsFetchCompleted: " + JSON.stringify(products));
    });

    /**********************************
     * Product purchase
     *******************************/

    CocoonJS.Store.onProductPurchaseStarted.addEventListener(function(productId) {
        console.log("onProductPurchaseStarted");
        console.log(JSON.stringify(arguments));
    });

    CocoonJS.Store.onProductPurchaseFailed.addEventListener(function(productId, err) {
        console.log("onProductPurchaseFailed");
        console.log(JSON.stringify(arguments));
    });

    CocoonJS.Store.onProductPurchaseCompleted.addEventListener(function(purchaseInfo) {
        console.log("onProductPurchaseCompleted");
        console.log(JSON.stringify(arguments));

        CocoonJS.Store.consumePurchase(purchaseInfo.transactionId, purchaseInfo.productId);
        CocoonJS.Store.finishPurchase(purchaseInfo.transactionId);

    });

    /**********************************	
     * Consume purchase mode
     *******************************/

    CocoonJS.Store.onConsumePurchaseStarted.addEventListener(function(transactionId) {
        console.log("onConsumePurchaseStarted");
        console.log(JSON.stringify(arguments));
    });
    CocoonJS.Store.onConsumePurchaseCompleted.addEventListener(function(transactionId) {
        console.log("onConsumePurchaseCompleted");
        console.log(JSON.stringify(arguments));
    });
    CocoonJS.Store.onConsumePurchaseFailed.addEventListener(function(transactionId, err) {
        console.log("onConsumePurchaseFailed");
        console.log(JSON.stringify(arguments));
    });

    /**********************************
     * Restore purchases mode
     *******************************/

    CocoonJS.Store.onRestorePurchasesStarted.addEventListener(function() {
        console.log("onRestorePurchasesStarted");
    });

    CocoonJS.Store.onRestorePurchasesFailed.addEventListener(function(errorMessage) {
        console.log("onRestorePurchasesFailed");
        console.log(errorMessage);
    });

    CocoonJS.Store.onRestorePurchasesCompleted.addEventListener(function() {
        console.log("onRestorePurchasesCompleted");
    });

    /**********************************
     * THIS IS ONLY USED IN UNMANAGED MODE
     *******************************/
    CocoonJS.Store.onProductPurchaseVerificationRequestReceived.addEventListener(function(productId, data) {
        console.log("onProductPurchaseVerificationRequestReceived");


        //in iOS refer to:
        //https://developer.apple.com/library/ios/releasenotes/General/ValidateAppStoreReceipt/Chapters/ValidateRemotely.html#//apple_ref/doc/uid/TP40010573-CH104-SW1
        // An example of the implementing server is:
        // https://github.com/pcrawfor/iap_verifier

        // in Android refer to:
        // https://developer.android.com/google/play/billing/gp-purchase-status-api.html#overview
        //
        //An example of implementing server is:
        //https://www.npmjs.org/package/iab_verifier

        console.log("********************************************");
        console.log("CURRENT PRODUCTS ON LOCAL DATABASE:\n\n\n\n\n\n");
        console.log(JSON.stringify(CocoonJS.Store.getProducts()));
        console.log("********************************************");

        CocoonJS.Store.consumePurchase(orderId, productId);
        console.log("======= orderID : " + orderId + "productId  " + productId + " consumed =========");
        CocoonJS.Store.finishPurchase(orderId);
        console.log("======= purchase finished ===========");
    });

    /**********************************
     * START THE DEMO
     *******************************/

    CocoonJS.Store.requestInitialization({
        sandbox: true,
        managed: true
    });

    CocoonJS.Store.start();

    document.body.addEventListener("click", function(evt) {
        CocoonJS.App.onTextDialogFinished.addEventListener(function(productId) {
            a = productId;
            CocoonJS.Store.fetchProductsFromStore([a]);
        });

    });

    var canvas = document.createElement("canvas");
    canvas.width = 480;
    canvas.height = 360;
    canvas.style.cssText = "idtkscale:ScaleToFill;";
    var ctx = canvas.getContext("2d");


    var img = document.createElement("img");
    img.onload = function(e) {
        ctx.drawImage(e.target, 0, 0);
    }

    img.src = "background.jpg";

    canvas.addEventListener("click", function(e) {
        x = e.clientX;
        y = e.clientY;

        if (x >= 64 && x <= 373 && y >= 63 && y <= 87) {
            console.log("Fetch product from store");
            CocoonJS.App.showTextDialog("Product id", "fetchProductsFromStore", "remove.ads", CocoonJS.App.KeyboardType.TEXT, "Cancel", "Ok");
        } else if (x >= 107 && x <= 365 && y >= 171 && y <= 193) {
            console.log("Purchase product");
            CocoonJS.Store.purchaseProduct(a);
        } else if (x >= 97 && x <= 376 && y >= 269 && y <= 289) {
            console.log("Restore purchases");
            CocoonJS.Store.restorePurchases();
        }

    });
    document.body.appendChild(canvas);
})();