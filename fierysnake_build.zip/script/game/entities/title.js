ENGINE.Title = Compose(ENGINE.SpriteEntity, {
    image: "logo.png",

    create: Compose.after(function() {}),

    step: function(delta) {

    },

    disparition: function() {}

});